how to run:
a) expects a graph file as input with first line saying #vertices #edges and #sources, followed by sorted edges.
b) ./executable < input.txt > output.txt