how to run:
 ./executable inputsize  basecase
 ./par 1024 32