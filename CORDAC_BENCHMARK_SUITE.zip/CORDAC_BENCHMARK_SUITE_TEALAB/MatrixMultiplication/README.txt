how to run:
 ./executable inputsize  basecase
 ./mm 1024 32