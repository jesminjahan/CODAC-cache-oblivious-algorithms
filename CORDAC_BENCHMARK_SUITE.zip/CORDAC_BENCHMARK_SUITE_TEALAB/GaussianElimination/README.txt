how to run:
 ./executable inputsize  basecase
 ./gauss