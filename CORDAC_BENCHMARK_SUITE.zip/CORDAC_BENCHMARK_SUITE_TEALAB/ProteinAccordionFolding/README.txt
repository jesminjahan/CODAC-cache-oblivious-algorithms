how to run:
 ./executable inputsize  basecase
 ./pf 1024 32